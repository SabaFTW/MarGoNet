export function latLonToXYZ(lat: number, lon: number, radius: number): [number, number, number] {
  const phi = ((90 - lat) * Math.PI) / 180;
  const theta = ((lon + 180) * Math.PI) / 180;
  const sinPhi = Math.sin(phi);
  return [
    -radius * sinPhi * Math.cos(theta),
    radius * Math.cos(phi),
    radius * sinPhi * Math.sin(theta),
  ];
}

export function xyzToLatLon(x: number, y: number, z: number) {
  const radius = Math.hypot(x, y, z) || 1;
  const lat = 90 - (Math.acos(Math.min(1, Math.max(-1, y / radius))) * 180) / Math.PI;
  let lon = (Math.atan2(z, -x) * 180) / Math.PI - 180;
  if (lon > 180) lon -= 360;
  if (lon <= -180) lon += 360;
  return { lat, lon };
}
